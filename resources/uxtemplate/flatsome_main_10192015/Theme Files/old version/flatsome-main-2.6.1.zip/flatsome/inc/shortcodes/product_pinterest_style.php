<?php 

// Depricated. This is now located in products.php.