This folder contain two files.

The correct file to install is 'flatsome-main-**.zip'.

--------------

The 'flatsome-child.zip' is if you want to create a child theme of Flatsome.
Learn more about Child Themes here: https://codex.wordpress.org/Child_Themes